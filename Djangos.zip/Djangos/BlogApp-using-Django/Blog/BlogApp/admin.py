from django.contrib import admin
from BlogApp.models import Posts,Author
# Register your models here.
admin.site.register(Posts)
admin.site.register(Author)
