# BlogApp-using-Django

# Deployment Link : http://jatinsadhwani.pythonanywhere.com/

This is a BlogApp where user can write post and he can also write, update and delete his own post only. I have used Python, Django, Flask, HTML, CSS and Bootstrap.
